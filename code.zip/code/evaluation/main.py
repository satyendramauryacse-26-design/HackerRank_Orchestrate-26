from pathlib import Path
import subprocess
import sys

script = Path(__file__).with_name("main.js")
result = subprocess.run(["node", str(script)], cwd=script.parent.parent, check=False)
sys.exit(result.returncode)