# Evaluation Report

## Public sample validation

The agent was run against the 32 supplied sample requests and compared with `dataset/sample_output.csv`. This public sample is the only answer set available; the hidden 518-case set has no local ground-truth answers, so hidden-set predictive accuracy cannot be calculated.

| Metric | Result |
|---|---:|
| Case-level deletion-status accuracy | 27/32 (84.38%) |
| Exact case/row accuracy (status and complete ordered steps) | 6/32 (18.75%) |
| Exact ordered sequence accuracy | 6/32 (18.75%) |
| Step-level exact accuracy | 100/193 (51.81%) |
| Step-field accuracy | 846/1,351 (62.62%) |

The evaluator validates all 518 output rows, CSV ordering, valid JSON arrays, consecutive step numbers, allowed statuses, evidence-backed verification for every `COMPLETE` row, and empty arrays for `NOT_APPLICABLE`.

## Additional team-created evaluation cases

Four synthetic contract tests are run by `code/evaluation/main.js`:

1. An export-only request is `NOT_APPLICABLE` with no steps.
2. A present user profile produces a finding, deletion remediation, and absence verification in phase order.
3. An active connector produces a finding, disable action, and disabled-state verification.
4. A deletion with no supporting evidence cannot be labeled `COMPLETE`.

All four contract tests passed in the final evaluation run.

## Failures found and improvements made

- Initial intent detection missed common inflections and multilingual deletion wording. The classifier was broadened and the public-sample status score improved from 11/32 to 27/32 during iteration.
- The first parser assumed SQL snapshots stored JSON in a fixed tuple position. It now reads table column declarations and associates values by column, including replica data.
- Scan logs and PDF text use different layouts. The parser now handles key/value log records and extracts PDF text locally; local OCR covers the supplied screenshots.
- Identity matching now incorporates current and historical email, phone, name, hash, and stable user references, and resolves later states for resources first linked by an earlier record.
- Cases with no evidence-backed verification are now left `INCOMPLETE` instead of being falsely marked `COMPLETE`. This is conservative but some such rows have no actionable steps because no resource can be grounded in participant-visible evidence.

Remaining sample mismatches primarily involve linking anonymized records that contain no surviving subject identifier, assigning an account resource ID when a snapshot proves no row but contains no ID, and differing evidence/step coverage. The solution deliberately does not infer missing resource IDs from case labels or copy sample-specific answers into full-dataset predictions.
