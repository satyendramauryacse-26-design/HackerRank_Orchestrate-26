import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  authorizedDeletion,
  collectUsers,
  makeOutputCase,
  readCsv,
  readEvidence,
} from "../main.js";

const EVALUATION_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(EVALUATION_DIR, "../..");

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
    } else if (char === "\n") {
      row.push(field.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (field || row.length) {
    row.push(field.replace(/\r$/, ""));
    rows.push(row);
  }
  const headers = rows.shift();
  return rows.filter((values) => values.length).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])),
  );
}

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonical(value[key])]));
  }
  return value;
}

const [sample, sampleRequests, identities, auditLog, manifest, rules, activity] = await Promise.all([
  fs.readFile(path.join(ROOT, "dataset", "sample_output.csv"), "utf8").then(parseCsv),
  readCsv(path.join(ROOT, "dataset", "sample_deletion_requests.csv")),
  readCsv(path.join(ROOT, "dataset", "user_identities.csv")),
  readCsv(path.join(ROOT, "dataset", "user_audit_log.csv")),
  readCsv(path.join(ROOT, "dataset", "evidence_files.csv")),
  readCsv(path.join(ROOT, "dataset", "deletion_rules.csv")),
  readCsv(path.join(ROOT, "dataset", "system_activity.csv")),
]);
const output = parseCsv(await fs.readFile(path.join(ROOT, "output.csv"), "utf8"));
const users = collectUsers(identities, auditLog);
const evidence = await readEvidence(manifest);
const policy = new Map(rules.map((rule) => [rule.data_category, rule.required_action]));
const samplePredictions = sampleRequests.map((request) => {
  const user = users.emailToUser.get(request.email.trim().toLocaleLowerCase("en-US"));
  if (!user) throw new Error(`Could not resolve public sample ${request.case_id}`);
  return makeOutputCase(request, user, evidence, policy, activity);
});
const outputById = new Map(samplePredictions.map((row) => [row.case_id, row]));
let correctStatuses = 0;
let exactRows = 0;
let expectedFieldCount = 0;
let correctFieldCount = 0;
let correctStepCount = 0;
let expectedStepCount = 0;
let exactSequences = 0;
const failures = [];

for (const expected of sample) {
  const actual = outputById.get(expected.case_id);
  assert.ok(actual, `Missing public sample ${expected.case_id}`);
  if (actual.deletion_status === expected.deletion_status) correctStatuses += 1;
  const expectedSteps = JSON.parse(expected.steps_json);
  const actualSteps = actual.steps_json;
  const sameRow = actual.deletion_status === expected.deletion_status &&
    JSON.stringify(canonical(actualSteps)) === JSON.stringify(canonical(expectedSteps));
  if (sameRow) exactRows += 1;
  const sameSequence = JSON.stringify(actualSteps.map((step) => [
    step.phase, step.operation, step.system_id, step.resource_id, step.state, step.evidence_id,
  ])) === JSON.stringify(expectedSteps.map((step) => [
    step.phase, step.operation, step.system_id, step.resource_id, step.state, step.evidence_id,
  ]));
  if (sameSequence) exactSequences += 1;

  const expectedFields = ["step_no", "phase", "system_id", "resource_id", "operation", "state", "evidence_id"];
  for (let i = 0; i < Math.max(expectedSteps.length, actualSteps.length); i += 1) {
    const expectedStep = expectedSteps[i];
    const actualStep = actualSteps[i];
    if (!expectedStep) continue;
    expectedStepCount += 1;
    if (actualStep && JSON.stringify(canonical(actualStep)) === JSON.stringify(canonical(expectedStep))) {
      correctStepCount += 1;
    }
    for (const field of expectedFields) {
      expectedFieldCount += 1;
      if (actualStep && actualStep[field] === expectedStep[field]) correctFieldCount += 1;
    }
  }
  if (!sameRow && failures.length < 12) {
    failures.push({
      case_id: expected.case_id,
      expected_status: expected.deletion_status,
      actual_status: actual.deletion_status,
      expected_steps: expectedSteps.length,
      actual_steps: actualSteps.length,
      expected: expectedSteps.map(({ phase, operation, system_id, resource_id, state, evidence_id }) =>
        [phase, operation, system_id, resource_id, state, evidence_id]),
      actual: actualSteps.map(({ phase, operation, system_id, resource_id, state, evidence_id }) =>
        [phase, operation, system_id, resource_id, state, evidence_id]),
    });
  }
}

assert.equal(output.length, 518, "Output must contain all 518 requests");
assert.deepEqual(output.map((row) => row.case_id), [...output.map((row) => row.case_id)].sort(
  (a, b) => a.localeCompare(b, undefined, { numeric: true }),
), "Output cases must be sorted");
for (const row of output) {
  const steps = JSON.parse(row.steps_json);
  assert.ok(["COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"].includes(row.deletion_status));
  assert.ok(Array.isArray(steps));
  assert.deepEqual(steps.map((step) => step.step_no), steps.map((_, index) => index + 1));
  if (row.deletion_status === "NOT_APPLICABLE") assert.equal(steps.length, 0);
  if (row.deletion_status === "COMPLETE") {
    assert.ok(steps.length > 0, `Complete case ${row.case_id} requires evidence-backed checks`);
    assert.ok(steps.every((step) => step.phase === "VERIFICATION" && step.evidence_id));
  }
}

const syntheticUser = { userId: "user_test", values: new Set(["user_test", "test@example.invalid"]) };
const baseRequest = {
  case_id: "custom_case",
  audit_at: "2026-10-01T12:00:00Z",
  request_text: "Please permanently delete my account.",
};
const activeFlow = {
  resourceId: "data_flow_17",
  category: "DATA_FLOW",
  systemId: "integration_service",
  state: "ACTIVE",
  timestamp: "2026-10-01T11:00:00Z",
  evidenceId: "evidence_test",
  values: ["test@example.invalid", "user_test"],
  record: { email: "test@example.invalid", enabled: true },
  text: "",
};

const customCases = [
  {
    name: "non-deletion request has no authorized steps",
    run: () => {
      assert.equal(authorizedDeletion("Please export a copy of my account data."), false);
      const result = makeOutputCase(
        { ...baseRequest, request_text: "Please export a copy of my account data." },
        syntheticUser,
        [activeFlow],
        new Map(),
        [],
      );
      assert.equal(result.deletion_status, "NOT_APPLICABLE");
      assert.deepEqual(result.steps_json, []);
    },
  },
  {
    name: "present profile is removed and verified",
    run: () => {
      const profile = {
        ...activeFlow,
        resourceId: "account_17",
        category: "USER_PROFILE",
        systemId: "account_service",
        state: "PRESENT",
        record: { email: "test@example.invalid", account_status: "ACTIVE" },
      };
      const result = makeOutputCase(baseRequest, syntheticUser, [profile], new Map([["USER_PROFILE", "DELETE"]]), []);
      assert.equal(result.deletion_status, "INCOMPLETE");
      assert.deepEqual(result.steps_json.map((step) => step.operation), [
        "REPORT_REMAINING_RECORD",
        "DELETE_RECORD",
        "VERIFY_RECORD_ABSENT",
      ]);
    },
  },
  {
    name: "active connector is disabled before its verification",
    run: () => {
      const result = makeOutputCase(baseRequest, syntheticUser, [activeFlow], new Map(), []);
      assert.equal(result.deletion_status, "INCOMPLETE");
      assert.deepEqual(result.steps_json.map((step) => step.operation), [
        "REPORT_ACTIVE_DATA_FLOW",
        "DISABLE_DATA_FLOW",
        "VERIFY_DATA_FLOW_DISABLED",
      ]);
    },
  },
  {
    name: "missing evidence cannot produce a false complete result",
    run: () => {
      const result = makeOutputCase(baseRequest, syntheticUser, [], new Map(), []);
      assert.equal(result.deletion_status, "INCOMPLETE");
      assert.deepEqual(result.steps_json, []);
    },
  },
];
for (const testCase of customCases) testCase.run();

const metrics = {
  sample_cases: sample.length,
  case_status_accuracy: `${correctStatuses}/${sample.length}`,
  exact_row_accuracy: `${exactRows}/${sample.length}`,
  step_accuracy: `${correctStepCount}/${expectedStepCount}`,
  field_accuracy: `${correctFieldCount}/${expectedFieldCount}`,
  exact_sequence_accuracy: `${exactSequences}/${sample.length}`,
  additional_cases: customCases.map(({ name }) => name),
  failures,
};
console.log(JSON.stringify(metrics, null, 2));
