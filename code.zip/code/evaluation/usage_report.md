# Token Usage and Cost Report

## Final full-dataset run

- Requests processed: 518
- Prediction model provider: None (no remote provider)
- Prediction model name: None (prediction logic is deterministic)
- Local OCR provider: Tesseract.js, English `eng.traineddata` 4.0.0
- Local OCR calls: 11 image-recognition calls
- LLM/API model calls: 0
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0
- Average tokens per request: 0
- Estimated total cost: $0.00
- Estimated cost per request: $0.00

Evidence extraction runs locally. PDF parsing uses `pdf-parse`; screenshot OCR uses the bundled Tesseract.js English model. Local OCR does not use an API provider and has no billable token usage. The four PDFs are parsed locally with `pdf-parse`; no credentials or external model services are required.
