# Ghost Data Deletion Audit

This solution uses deterministic evidence extraction and policy-driven state reconstruction. It does not send dataset contents to an external service or make LLM/API calls.

## Run

Requirements: Node.js 20 or newer and npm.

From the repository root:

```powershell
npm --prefix .\code install
npm --prefix .\code run run
npm --prefix .\code run evaluate
```

The audit reads participant-facing CSV files, JSON and SQL snapshots, logs, PDFs, and screenshots under `dataset/`. PDF text is extracted locally; screenshots are OCR-processed locally with the bundled English Tesseract data. Results are written to root-level `output.csv`.

The audit resolves current and historical identifiers, filters evidence to the case cutoff, applies `deletion_rules.csv`, and orders findings, remediations, and verification steps by the required operation and resource order. `evaluation/main.js` compares the public sample set and runs additional contract checks.

The `main.py` files are small Python standard-library launchers for environments that invoke the original starter entry points; they delegate to the JavaScript implementation and do not contain a second audit path.

## Submission packaging

Create `code.zip` from the repository root, including `code/` and excluding `node_modules` and the dataset:

```powershell
Compress-Archive -Path .\code\main.js, .\code\package.json, .\code\package-lock.json, .\code\README.md, .\code\evaluation -DestinationPath .\code.zip -Force
```

The generated archive must not contain `dataset/`, `node_modules/`, or build artifacts.
