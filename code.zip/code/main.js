import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createWorker } from "tesseract.js";
import pdfParse from "pdf-parse";
import englishData from "@tesseract.js-data/eng";

const CODE_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(CODE_DIR, "..");
const DATASET = path.join(ROOT, "dataset");
const OUTPUT = path.join(ROOT, "output.csv");

const OPERATION_ORDER = {
  FINDING: [
    "REPORT_REMAINING_RECORD",
    "REPORT_EXPOSED_PII",
    "REPORT_ACTIVE_DATA_FLOW",
    "REPORT_RESTORE_RISK",
  ],
  REMEDIATION: [
    "DISABLE_DATA_FLOW",
    "BLOCK_RESTORE",
    "DELETE_RECORD",
    "REDACT_RECORD",
    "ANONYMIZE_RECORD",
  ],
  VERIFICATION: [
    "VERIFY_RECORD_ABSENT",
    "VERIFY_RECORD_PRESENT",
    "VERIFY_RECORD_REDACTED",
    "VERIFY_RECORD_ANONYMIZED",
    "VERIFY_DATA_FLOW_DISABLED",
    "VERIFY_RESTORE_BLOCKED",
  ],
};

const CATEGORY_BY_PREFIX = [
  ["account_", "USER_PROFILE"],
  ["tombstone_", "ACCOUNT_TOMBSTONE"],
  ["secondary_", "SECONDARY_IDENTIFIER"],
  ["search_", "SEARCH_INDEX_ENTRY"],
  ["cache_", "CACHE_ENTRY"],
  ["support_", "SUPPORT_MESSAGE"],
  ["analytics_", "ANALYTICS_PROFILE"],
  ["telemetry_", "PRODUCT_TELEMETRY"],
  ["export_", "USER_EXPORT"],
  ["marketing_", "MARKETING_PROFILE"],
  ["email_delivery_", "EMAIL_DELIVERY_LOG"],
  ["audit_record_", "SECURITY_AUDIT_LOG"],
  ["legal_hold_", "LEGAL_HOLD_RECORD"],
  ["backup_", "BACKUP_ARCHIVE"],
  ["data_flow_", "DATA_FLOW"],
];

const SYSTEM_BY_CATEGORY = {
  USER_PROFILE: "account_service",
  ACCOUNT_TOMBSTONE: "account_service",
  SECONDARY_IDENTIFIER: "identity_service",
  SEARCH_INDEX_ENTRY: "search_service",
  CACHE_ENTRY: "cache_service",
  SUPPORT_MESSAGE: "support_platform",
  SUPPORT_ATTACHMENT: "support_platform",
  ANALYTICS_PROFILE: "analytics_platform",
  PRODUCT_TELEMETRY: "telemetry_service",
  USER_EXPORT: "export_service",
  MARKETING_PROFILE: "marketing_service",
  EMAIL_DELIVERY_LOG: "email_delivery_service",
  SECURITY_AUDIT_LOG: "security_service",
  LEGAL_HOLD_RECORD: "legal_service",
  BACKUP_ARCHIVE: "backup_service",
  DATA_FLOW: "integration_service",
};

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
    } else if (char === "\n") {
      row.push(field.replace(/\r$/, ""));
      if (row.some((cell) => cell.length > 0)) rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (field.length || row.length) {
    row.push(field.replace(/\r$/, ""));
    if (row.some((cell) => cell.length > 0)) rows.push(row);
  }
  if (rows.length === 0) return [];
  const headers = rows.shift();
  return rows.map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])),
  );
}

async function readCsv(filePath) {
  return parseCsv(await fs.readFile(filePath, "utf8"));
}

function writeCsvField(value) {
  const string = String(value);
  return /[",\r\n]/.test(string) ? `"${string.replaceAll('"', '""')}"` : string;
}

function normalize(value) {
  return String(value ?? "").trim().toLocaleLowerCase("en-US");
}

function normalizePhone(value) {
  return String(value ?? "").replace(/\D/g, "");
}

function objectValues(value, result = []) {
  if (value === null || value === undefined) return result;
  if (typeof value === "object") {
    for (const child of Object.values(value)) objectValues(child, result);
  } else {
    result.push(String(value));
  }
  return result;
}

function identityValues(value) {
  const direct = new Set();
  const linkable = new Set();
  for (const item of value.values) {
    const normalized = normalize(item);
    if (!normalized) continue;
    linkable.add(normalized);
    if (!/^user_[a-z0-9_-]+$/i.test(normalized) && !/^\d{4}-\d\d-\d\dT/.test(normalized)) {
      direct.add(normalized);
    }
    const digits = normalizePhone(item);
    if (digits.length >= 8) {
      linkable.add(`phone:${digits}`);
      direct.add(`phone:${digits}`);
    }
  }
  if (value.userId) linkable.add(normalize(value.userId));
  return { direct, linkable };
}

function valuesMatch(values, identity) {
  for (const value of values) {
    const normalized = normalize(value);
    if (identity.linkable.has(normalized)) return true;
    const digits = normalizePhone(value);
    if (digits.length >= 8 && identity.linkable.has(`phone:${digits}`)) return true;
  }
  return false;
}

function textMatchesIdentity(text, identity) {
  const lower = normalize(text);
  for (const value of identity.linkable) {
    const needle = value.startsWith("phone:") ? value.slice(6) : value;
    if (needle.length >= 8 && lower.includes(needle)) return true;
  }
  return false;
}

function inferredCategory(resourceId, record) {
  const categoryFields = [
    record.record_type,
    record.data_category,
    record.collection,
    record.collection_name,
    record.category,
    record.type,
  ];
  const normalized = categoryFields
    .filter((value) => typeof value === "string")
    .join(" ")
    .toUpperCase();
  const known = [
    "USER_PROFILE",
    "ACCOUNT_TOMBSTONE",
    "SECONDARY_IDENTIFIER",
    "SEARCH_INDEX_ENTRY",
    "CACHE_ENTRY",
    "SUPPORT_MESSAGE",
    "SUPPORT_ATTACHMENT",
    "ANALYTICS_PROFILE",
    "PRODUCT_TELEMETRY",
    "USER_EXPORT",
    "MARKETING_PROFILE",
    "EMAIL_DELIVERY_LOG",
    "SECURITY_AUDIT_LOG",
    "LEGAL_HOLD_RECORD",
    "BACKUP_ARCHIVE",
    "DATA_FLOW",
  ];
  for (const category of known) {
    if (normalized.includes(category)) return category;
  }
  const resource = String(resourceId ?? "").toLowerCase();
  return CATEGORY_BY_PREFIX.find(([prefix]) => resource.startsWith(prefix))?.[1] ?? "";
}

function inferSystem(record, category, resourceId) {
  const supplied = [
    record.system_id,
    record.system,
    record.data_store,
    record.source_system,
    record.target_system,
    record.service,
    record.origin_system,
  ]
    .filter((value) => typeof value === "string")
    .join(" ")
    .toLowerCase();
  for (const [needle, system] of Object.entries(SYSTEM_BY_CATEGORY)) {
    if (supplied.includes(system.replace("_", " ")) || supplied.includes(system)) return system;
    if (supplied.includes(needle.toLowerCase())) return system;
  }
  if (supplied.includes("account")) return "account_service";
  if (supplied.includes("search")) return "search_service";
  if (supplied.includes("support")) return "support_platform";
  if (supplied.includes("analytics")) return "analytics_platform";
  if (supplied.includes("integration") || supplied.includes("connector")) return "integration_service";
  if (supplied.includes("backup") || supplied.includes("restore")) return "backup_service";
  if (supplied.includes("security") || supplied.includes("audit")) return "security_service";
  if (supplied.includes("export")) return "export_service";
  if (supplied.includes("marketing")) return "marketing_service";
  if (supplied.includes("telemetry")) return "telemetry_service";
  return SYSTEM_BY_CATEGORY[category] ?? (String(resourceId).startsWith("data_flow_") ? "integration_service" : "");
}

function firstValue(object, names) {
  for (const name of names) {
    const value = object?.[name];
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return "";
}

function stateFromRecord(record, category, text = "") {
  const status = normalize(
    firstValue(record, [
      "result",
      "state",
      "status",
      "account_status",
      "record_status",
      "lookup_status",
      "restore_status",
    ]),
  );
  if (/not found|not_found|no hit|no rows|absent|deleted|404/.test(status)) return "ABSENT";
  if (/anonymized|anonymised|deidentified|de-identified/.test(status)) return "ANONYMIZED";
  if (/redacted|masked/.test(status)) return "REDACTED";
  if (category === "DATA_FLOW") {
    const enabled = firstValue(record, ["enabled", "active", "is_active", "connector_enabled"]);
    if (enabled === true || normalize(enabled) === "true" || normalize(enabled) === "1") return "ACTIVE";
    if (enabled === false || normalize(enabled) === "false" || normalize(enabled) === "0") return "DISABLED";
    if (/disabled|stopped|inactive/.test(status)) return "DISABLED";
    if (/active|enabled|connected|delivered|healthy/.test(status)) return "ACTIVE";
  }
  if (category === "BACKUP_ARCHIVE") {
    const allowed = firstValue(record, ["restore_allowed", "restore_enabled", "can_restore"]);
    if (allowed === true || normalize(allowed) === "true" || normalize(allowed) === "1") return "ACTIVE";
    if (allowed === false || normalize(allowed) === "false" || normalize(allowed) === "0") return "BLOCKED";
    if (/blocked|false/.test(status)) return "BLOCKED";
    if (/active|allowed|enabled|true/.test(status)) return "ACTIVE";
  }
  if (status) {
    if (/found|present|identifiable|success|hit|retained|active/.test(status)) return "PRESENT";
  }
  if (/result=(?:not_found|miss)|http_status=404|rows=0|status_code=404/i.test(text)) return "ABSENT";
  if (/anonymized|anonymised/i.test(text)) return "ANONYMIZED";
  if (/redacted|masked/i.test(text)) return "REDACTED";
  if ((category === "ANALYTICS_PROFILE" || category === "PRODUCT_TELEMETRY") &&
      ["user_id", "customer_reference", "subject_reference", "email", "phone", "email_hash"]
        .some((key) => Object.hasOwn(record, key)) &&
      ["user_id", "customer_reference", "subject_reference", "email", "phone", "email_hash"]
        .every((key) => !Object.hasOwn(record, key) || record[key] === null || record[key] === "")) {
    return "ANONYMIZED";
  }
  if (/enabled=false|restore_allowed=false|restore_allowed=0/i.test(text)) {
    return category === "BACKUP_ARCHIVE" ? "BLOCKED" : "DISABLED";
  }
  if (/enabled=true|restore_allowed=true|restore_allowed=1/i.test(text)) {
    return category === "BACKUP_ARCHIVE" ? "ACTIVE" : "ACTIVE";
  }
  return "PRESENT";
}

function recordTime(record, fallback) {
  const candidate = firstValue(record, [
    "recorded_at",
    "observed_at",
    "captured_at",
    "updated_at",
    "indexed_at",
    "event_time",
    "timestamp",
    "created_at",
  ]);
  return /^\d{4}-\d{2}-\d{2}T/.test(String(candidate)) ? String(candidate) : fallback;
}

function makeEvidenceRecord(record, context, evidenceId, fileTimestamp, text = "") {
  const resourceId = String(firstValue(record, ["resource_id", "id", "_id"]));
  if (!resourceId) return null;
  const category = inferredCategory(resourceId, { ...context, ...record });
  if (!category) return null;
  const combined = { ...context, ...record };
  const values = objectValues(combined);
  const systemId = inferSystem(combined, category, resourceId);
  if (!systemId) return null;
  return {
    resourceId,
    category,
    systemId,
    state: stateFromRecord(combined, category, text),
    timestamp: recordTime(combined, fileTimestamp),
    capturedAt: fileTimestamp,
    evidenceId,
    values,
    record: combined,
    text,
  };
}

function walkJson(value, context, evidenceId, fileTimestamp, found) {
  if (!value || typeof value !== "object") return;
  const nextContext = { ...context };
  for (const key of [
    "data_store",
    "collection",
    "collection_name",
    "record_type",
    "system",
    "system_id",
    "source_system",
    "captured_at",
    "recorded_at",
    "observed_at",
    "exported_at",
  ]) {
    if (value[key] !== undefined) nextContext[key] = value[key];
  }
  if (value.resource_id || value._id) {
    const record = makeEvidenceRecord(value, nextContext, evidenceId, fileTimestamp);
    if (record) found.push(record);
  }
  for (const child of Object.values(value)) {
    if (child && typeof child === "object") walkJson(child, nextContext, evidenceId, fileTimestamp, found);
  }
}

function parseSqlRecords(text, evidenceId, fileTimestamp) {
  const result = [];
  const schemas = new Map();
  const schemaPattern = /CREATE\s+TABLE\s+["`]?(\w+)["`]?\s*\(([\s\S]*?)\);/gi;
  for (const match of text.matchAll(schemaPattern)) {
    const columns = splitSqlValues(match[2]).map((definition) => {
      if (/^\s*(?:PRIMARY|FOREIGN|UNIQUE|CHECK|CONSTRAINT)\b/i.test(definition)) return "";
      const name = definition.trim().match(/^(?:["`]?)([a-z_][a-z0-9_]*)(?:["`]?)\s+/i)?.[1];
      return name?.toLowerCase() ?? "";
    }).filter(Boolean);
    schemas.set(match[1].toLowerCase(), columns);
  }
  const pattern = /INSERT\s+INTO\s+["`]?(\w+)["`]?(?:\s*\(([^)]*)\))?\s+VALUES\s*\(([\s\S]*?)\);/gi;
  for (const match of text.matchAll(pattern)) {
    const tableName = match[1].toLowerCase();
    const columns = match[2]
      ? match[2].split(",").map((column) => column.trim().replace(/["`]/g, "").toLowerCase())
      : schemas.get(tableName) ?? [];
    const values = splitSqlValues(match[3]);
    if (columns.length !== values.length) continue;
    const row = Object.fromEntries(columns.map((column, index) => [column, parseSqlLiteral(values[index])]));
    let record = row;
    const jsonValue = row.record_json ?? row.payload_json ?? row.data_json;
    if (typeof jsonValue === "string") {
      try {
        record = { ...row, ...JSON.parse(jsonValue) };
      } catch {
        continue;
      }
    }
    if (!record.resource_id) continue;
    const parsed = makeEvidenceRecord(
      record,
      {
        data_store: row.origin_system ?? row.system_id ?? row.source_system ?? "",
        collection_name: row.collection_name ?? row.table_name ?? tableName,
        system: row.origin_system ?? row.system_id ?? row.source_system ?? "",
      },
      evidenceId,
      fileTimestamp,
    );
    if (parsed) result.push(parsed);
  }
  return result;
}

function splitSqlValues(input) {
  const values = [];
  let token = "";
  let quoted = false;
  let depth = 0;
  for (let i = 0; i < input.length; i += 1) {
    const char = input[i];
    if (quoted) {
      if (char === "'" && input[i + 1] === "'") {
        token += "''";
        i += 1;
      } else if (char === "'") {
        quoted = false;
        token += char;
      } else {
        token += char;
      }
    } else if (char === "'") {
      quoted = true;
      token += char;
    } else if (char === "(") {
      depth += 1;
      token += char;
    } else if (char === ")") {
      depth -= 1;
      token += char;
    } else if (char === "," && depth === 0) {
      values.push(token.trim());
      token = "";
    } else {
      token += char;
    }
  }
  if (token.trim()) values.push(token.trim());
  return values;
}

function parseSqlLiteral(input) {
  const value = input.trim();
  if (/^NULL$/i.test(value)) return null;
  if (value.startsWith("'") && value.endsWith("'")) {
    return value.slice(1, -1).replaceAll("''", "'");
  }
  if (/^-?\d+(?:\.\d+)?$/.test(value)) return Number(value);
  return value;
}

function parseTextRecords(text, evidenceId, fileTimestamp, documentWide = false) {
  const results = [];
  for (const line of text.split(/\r?\n/)) {
    const resourceMatch = line.match(/\b(?:resource_id|resource|_id)\s*[=:]\s*["']?([a-z][a-z0-9_-]*_\d+)["']?/i)
      ?? line.match(/\b((?:account|tombstone|secondary|search|cache|support|analytics|telemetry|export|marketing|email_delivery|audit_record|legal_hold|backup|data_flow)_\d+)\b/i);
    const pipe = line.split(/\s+\|\s+/);
    const resourceId = resourceMatch
      ? resourceMatch[1]
      : (pipe.length >= 5 ? pipe[2] : "");
    if (!resourceId) continue;
    const fields = Object.fromEntries(
      [...line.matchAll(/([a-z_]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))/gi)].map((match) => [
        match[1].toLowerCase(),
        (() => {
          const value = match[2] ?? match[3] ?? match[4] ?? "";
          return normalize(value) === "null" ? null : value;
        })(),
      ]),
    );
    if (pipe.length >= 5) {
      fields.system = pipe[1];
      fields.resource_id = pipe[2];
      fields.record_type = pipe[3];
      fields.result = pipe[4];
      fields.subject_reference = pipe[5] ?? "";
    }
    fields.resource_id = resourceId;
    fields.timestamp = line.match(/\b\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z\b/)?.[0] ?? "";
    const category = inferredCategory(resourceId, fields);
    const service = line.match(/\bservice=([a-z0-9_-]+)/i)?.[1];
    if (service && !fields.service) fields.service = service;
    const parsed = makeEvidenceRecord(fields, {}, evidenceId, fileTimestamp, line);
    if (parsed) results.push(parsed);
  }
  if (documentWide) {
    const resourceIds = new Set(
      [...text.matchAll(/\b((?:account|tombstone|secondary|search|cache|support|analytics|telemetry|export|marketing|email_delivery|audit_record|legal_hold|backup|data_flow)_\d+)\b/gi)]
        .map((match) => match[1]),
    );
    for (const resourceId of resourceIds) {
      const upper = text.toUpperCase();
      let recordType = inferredCategory(resourceId, {});
      if (resourceId.startsWith("support_") && /ATTACHMENT|IDENTITY DOCUMENT/i.test(text)) {
        recordType = "SUPPORT_ATTACHMENT";
      } else if (resourceId.startsWith("audit_record_")) {
        recordType = "SECURITY_AUDIT_LOG";
      }
      const email = (text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0] ?? "")
        .replace(/^(?:detail|record)/i, "");
      const userId = text.match(/\buser_\d+\b/i)?.[0] ?? "";
      const record = {
        resource_id: resourceId,
        record_type: recordType,
        subject_reference: email || userId,
        source_text: text,
      };
      const parsed = makeEvidenceRecord(record, {}, evidenceId, fileTimestamp, text);
      if (parsed) results.push(parsed);
    }
  }
  return results;
}

function authorizedDeletion(text) {
  const value = normalize(text);
  if (/\b(?:do not|don't|never|without)\s+(?:delete|erase|remove)\b|\bno (?:quiero|solicito) (?:borrar|eliminar)\b|\bne pas supprimer\b/.test(value)) {
    return false;
  }
  const deletionIntent = /\b(?:delet\w*|eras\w*|remov\w*|clos\w*|purge\w*|wipe\w*|suppression|suppress\w*|effac\w*|elimin\w*|borr\w*|suprim\w*|apag\w*|exclu\w*|encerr\w*)\b/.test(value)
    || /\b(?:remove|delete|erase)\b.{0,60}\b(?:profile|personal data|personal details|account|information|records)\b/.test(value)
    || /\b(?:profile|personal data|personal details|account|information|records)\b.{0,60}\b(?:remove|delete|erase)\b/.test(value)
    || /削除|消去|アカウント.*(?:閉鎖|削除)/.test(text);
  if (!deletionIntent) return false;
  const nonDeletionOnly = /\b(?:opt[\s-]?out|unsubscribe|stop marketing|correct my|update my|change my|rectify my|export my data|download my data|access my data)\b/.test(value)
    || /\b(?:acceso|exportar|corregir|actualizar|cambiar|cancelar marketing|désabonner|exporter|corriger|modifier)\b/.test(value);
  return !nonDeletionOnly || /\b(?:delet\w*|eras\w*|remov\w*|clos\w*|purge\w*|wipe\w*|suppression|suppress\w*|effac\w*|elimin\w*|borr\w*|suprim\w*|apag\w*|exclu\w*|encerr\w*)\b/.test(value);
}

function classifyTreatment(event, directExposure, policy) {
  const category = event.category;
  const record = event.record;
  const requiredAction = policy.get(category);
  if (category === "DATA_FLOW") return event.state === "ACTIVE" ? "FLOW" : "";
  if (category === "BACKUP_ARCHIVE") {
    if (event.state === "ACTIVE") return "RESTORE";
    return event.state === "BLOCKED" ? "RESTORE_BLOCKED" : "";
  }
  if (category === "SECURITY_AUDIT_LOG") return requiredAction === "RETAIN" ? "RETAIN" : "";
  if (category === "LEGAL_HOLD_RECORD") {
    const status = normalize(firstValue(record, ["hold_status", "legal_hold_status", "status", "result"]));
    return requiredAction === "RETAIN" && /active|found|present|retained/.test(status) ? "RETAIN" : "";
  }
  if (category === "ACCOUNT_TOMBSTONE") {
    const hasDirectFields = hasDirectIdentifierFields(record);
    return requiredAction === "REDACT" ? (hasDirectFields ? "REDACT" : "REDACTED") : "";
  }
  if (category === "SUPPORT_MESSAGE" || category === "SUPPORT_ATTACHMENT") {
    const sharedValue = firstValue(record, [
      "shared_context",
      "shared_customer_context",
      "contains_shared_context",
      "retain_conversation",
    ]);
    const shared = sharedValue !== false && normalize(sharedValue) !== "false" ||
      /shared customer|shared context|another customer|agent context/i.test(JSON.stringify(record));
    if (requiredAction === "REDACT" && event.state === "REDACTED" && !directExposure) return "REDACTED";
    if (category === "SUPPORT_ATTACHMENT") {
      const onlySubject = firstValue(record, ["belongs_only_to_subject", "subject_only", "attachment_owner_only"]);
      if (requiredAction !== "DELETE") return "";
      return onlySubject === true || normalize(onlySubject) === "true" ? "DELETE" : directExposure ? "DELETE" : "";
    }
    if (directExposure && requiredAction === "DELETE") return "DELETE";
    return directExposure && requiredAction === "REDACT" && shared ? "REDACT" : "";
  }
  if (category === "EMAIL_DELIVERY_LOG") return directExposure && requiredAction === "REDACT" ? "REDACT" : "";
  if (category === "ANALYTICS_PROFILE" || category === "PRODUCT_TELEMETRY") {
    const reference = normalize(firstValue(record, ["user_id", "customer_reference", "subject_reference", "customer_id"]));
    const linkable = Boolean(reference && event.values.some((value) => normalize(value) === reference));
    const status = normalize(firstValue(record, ["status", "result", "privacy_state", "deletion_state"]));
    if (/anonymized|anonymised/.test(status) && !directExposure && !linkable) return "ANONYMIZED";
    return requiredAction === "ANONYMIZE" && (directExposure || linkable) ? "ANONYMIZE" : "";
  }
  if (category === "USER_PROFILE" || category === "SECONDARY_IDENTIFIER" ||
      category === "SEARCH_INDEX_ENTRY" || category === "CACHE_ENTRY" ||
      category === "USER_EXPORT" || category === "MARKETING_PROFILE") {
    return requiredAction === "DELETE" ? "DELETE" : "";
  }
  return "";
}

function hasDirectIdentifierFields(record) {
  const directKeys = /^(email|phone|name|full_name|display_name|email_hash|first_name|last_name|address|customer_name|requester_email|requester_phone)$/i;
  for (const [key, value] of Object.entries(record)) {
    if (directKeys.test(key) && value !== null && value !== undefined && String(value).trim() !== "") return true;
  }
  return false;
}

function directExposure(event, identity) {
  const searchableText = event.values.map(normalize).join(" ");
  if ([...identity.direct].some((identifier) => {
    if (identifier.startsWith("phone:")) return searchableText.replace(/\D/g, "").includes(identifier.slice(6));
    return identifier.length >= 4 && searchableText.includes(identifier);
  })) return true;
  function inspect(record) {
    if (!record || typeof record !== "object") return false;
    for (const [key, value] of Object.entries(record)) {
      if (/email|phone|name|hash/i.test(key) && value !== null && value !== undefined && String(value).trim() !== "") {
        const normalized = normalize(value);
        if (identity.direct.has(normalized) ||
            [...identity.direct].some((candidate) => candidate.startsWith("phone:") && candidate.slice(6) === normalizePhone(value))) {
          return true;
        }
      }
      const normalized = normalize(value);
      if (identity.direct.has(normalized)) return true;
      const digits = normalizePhone(value);
      if (digits.length >= 8 && identity.direct.has(`phone:${digits}`)) return true;
      if (value && typeof value === "object" && inspect(value)) return true;
    }
    return false;
  }
  if (inspect(event.record)) return true;
  if (event.category === "ACCOUNT_TOMBSTONE") return hasDirectIdentifierFields(event.record);
  return false;
}

function makeStep(phase, systemId, resourceId, operation, state, evidenceId) {
  return { phase, system_id: systemId, resource_id: resourceId, operation, state, evidence_id: evidenceId };
}

function orderSteps(steps, includeStepNumbers = true) {
  const phaseOrder = ["FINDING", "REMEDIATION", "VERIFICATION"];
  const ordered = [...steps].sort((a, b) => {
    const phaseDiff = phaseOrder.indexOf(a.phase) - phaseOrder.indexOf(b.phase);
    if (phaseDiff) return phaseDiff;
    const operationDiff = OPERATION_ORDER[a.phase].indexOf(a.operation) - OPERATION_ORDER[b.phase].indexOf(b.operation);
    if (operationDiff) return operationDiff;
    return a.system_id.localeCompare(b.system_id) || a.resource_id.localeCompare(b.resource_id);
  });
  return ordered.map((step, index) => includeStepNumbers ? { step_no: index + 1, ...step } : step);
}

function makeOutputCase(request, user, allEvidence, policy, activity) {
  if (!authorizedDeletion(request.request_text)) return { case_id: request.case_id, deletion_status: "NOT_APPLICABLE", steps_json: [] };
  const identity = identityValues(user);
  const cutoff = Date.parse(request.audit_at);
  const directMatches = allEvidence.filter((event) => {
    if (Date.parse(event.capturedAt ?? event.timestamp) > cutoff || Date.parse(event.timestamp) > cutoff) return false;
    return valuesMatch(event.values, identity) || textMatchesIdentity(event.text, identity);
  });
  const relatedKeys = new Set(directMatches.map((event) => `${event.systemId}\u0000${event.resourceId}`));
  const activityKeys = new Set(
    activity
      .filter((event) => Date.parse(event.event_time) <= cutoff && textMatchesIdentity(event.details, identity))
      .map((event) => `${event.target_system}\u0000${event.resource_id}`),
  );
  for (const key of activityKeys) {
    if ([...relatedKeys].some((relatedKey) => relatedKey.endsWith(`\u0000${key.split("\u0000")[1]}`))) {
      relatedKeys.add(key);
    }
  }
  const related = allEvidence.filter((event) => {
    if (Date.parse(event.capturedAt ?? event.timestamp) > cutoff || Date.parse(event.timestamp) > cutoff) return false;
    return relatedKeys.has(`${event.systemId}\u0000${event.resourceId}`) ||
      valuesMatch(event.values, identity) || textMatchesIdentity(event.text, identity);
  });

  const byResource = new Map();
  for (const event of related) {
    const key = `${event.systemId}\u0000${event.resourceId}`;
    const current = byResource.get(key);
    if (!current || Date.parse(event.timestamp) >= Date.parse(current.timestamp) ||
        (event.timestamp === current.timestamp && event.evidenceId.localeCompare(current.evidenceId) > 0)) {
      byResource.set(key, event);
    }
  }
  const states = [...byResource.values()];
  const findings = [];
  const remediations = [];
  const verifications = [];
  const violationEvents = new Map();

  for (const event of states) {
    const exposed = directExposure(event, identity) ||
      (event.category === "ACCOUNT_TOMBSTONE" && hasDirectIdentifierFields(event.record));
    const treatment = classifyTreatment(event, exposed, policy);
    let finding;
    let remediation;
    let verification;
    if (treatment === "FLOW") {
      finding = ["REPORT_ACTIVE_DATA_FLOW", "ACTIVE"];
      remediation = ["DISABLE_DATA_FLOW", "DISABLED"];
      verification = ["VERIFY_DATA_FLOW_DISABLED", "DISABLED"];
    } else if (treatment === "RESTORE") {
      finding = ["REPORT_RESTORE_RISK", "ACTIVE"];
      remediation = ["BLOCK_RESTORE", "BLOCKED"];
      verification = ["VERIFY_RESTORE_BLOCKED", "BLOCKED"];
    } else if (treatment === "RESTORE_BLOCKED") {
      verification = ["VERIFY_RESTORE_BLOCKED", "BLOCKED"];
    } else if (treatment === "DELETE") {
      if (event.state === "PRESENT") {
        finding = ["REPORT_REMAINING_RECORD", "PRESENT"];
        remediation = ["DELETE_RECORD", "ABSENT"];
      }
      verification = ["VERIFY_RECORD_ABSENT", "ABSENT"];
    } else if (treatment === "REDACT") {
      if (exposed) finding = ["REPORT_EXPOSED_PII", "PRESENT"];
      remediation = ["REDACT_RECORD", "REDACTED"];
      verification = ["VERIFY_RECORD_REDACTED", "REDACTED"];
    } else if (treatment === "ANONYMIZE") {
      if (exposed || event.state === "PRESENT") finding = ["REPORT_EXPOSED_PII", "PRESENT"];
      remediation = ["ANONYMIZE_RECORD", "ANONYMIZED"];
      verification = ["VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"];
    } else if (treatment === "RETAIN") {
      verification = ["VERIFY_RECORD_PRESENT", "PRESENT"];
    } else if (treatment === "REDACTED") {
      verification = ["VERIFY_RECORD_REDACTED", "REDACTED"];
    } else if (treatment === "ANONYMIZED") {
      verification = ["VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"];
    }

    if (finding) {
      findings.push(makeStep("FINDING", event.systemId, event.resourceId, finding[0], finding[1], event.evidenceId));
      violationEvents.set(`${event.systemId}\u0000${event.resourceId}`, { event, remediation, verification });
    } else if (remediation && !["RETAIN"].includes(treatment)) {
      // A policy-required transformation is only planned when the current record violates it.
      if ((treatment === "REDACT" && exposed) ||
          (treatment === "ANONYMIZE" && (exposed || event.state === "PRESENT"))) {
        violationEvents.set(`${event.systemId}\u0000${event.resourceId}`, { event, remediation, verification });
      }
    }
    if (verification) {
      verifications.push(makeStep("VERIFICATION", event.systemId, event.resourceId, verification[0], verification[1], event.evidenceId));
    }
  }

  const incomplete = violationEvents.size > 0;
  if (!incomplete) {
    if (verifications.length === 0) {
      return { case_id: request.case_id, deletion_status: "INCOMPLETE", steps_json: [] };
    }
    const steps = orderSteps(verifications);
    return { case_id: request.case_id, deletion_status: "COMPLETE", steps_json: steps };
  }

  const remediationSteps = [];
  const futureVerificationSteps = [];
  for (const { event, remediation, verification } of violationEvents.values()) {
    if (remediation) {
      remediationSteps.push(makeStep("REMEDIATION", event.systemId, event.resourceId, remediation[0], remediation[1], ""));
    }
    if (verification) {
      futureVerificationSteps.push(makeStep("VERIFICATION", event.systemId, event.resourceId, verification[0], verification[1], ""));
    }
  }

  for (const event of states) {
    if (event.category !== "SECURITY_AUDIT_LOG" && event.category !== "LEGAL_HOLD_RECORD") continue;
    const alreadyPlanned = futureVerificationSteps.some((step) => step.resource_id === event.resourceId) ||
      verifications.some((step) => step.resource_id === event.resourceId);
    if (!alreadyPlanned) {
      futureVerificationSteps.push(makeStep("VERIFICATION", event.systemId, event.resourceId, "VERIFY_RECORD_PRESENT", "PRESENT", ""));
    }
  }

  for (const event of states) {
    if (event.category !== "USER_PROFILE" || event.state !== "ABSENT") continue;
    const exists = futureVerificationSteps.some((step) => step.resource_id === event.resourceId);
    if (!exists) {
      futureVerificationSteps.push(makeStep("VERIFICATION", event.systemId, event.resourceId, "VERIFY_RECORD_ABSENT", "ABSENT", ""));
    }
  }
  for (const event of states) {
    const accountResource = firstValue(event.record, ["source_resource_id", "account_id", "account_resource_id"]);
    if (!String(accountResource).startsWith("account_")) continue;
    const exists = futureVerificationSteps.some((step) =>
      step.system_id === "account_service" && step.resource_id === accountResource);
    if (!exists) {
      futureVerificationSteps.push(makeStep(
        "VERIFICATION",
        "account_service",
        String(accountResource),
        "VERIFY_RECORD_ABSENT",
        "ABSENT",
        "",
      ));
    }
  }

  const plannedResources = new Set([...violationEvents.keys()]);
  for (const step of verifications) {
    const key = `${step.system_id}\u0000${step.resource_id}`;
    if (plannedResources.has(key)) continue;
    if (step.operation === "VERIFY_RECORD_PRESENT" || step.operation === "VERIFY_RECORD_REDACTED" ||
        step.operation === "VERIFY_RECORD_ANONYMIZED") {
      futureVerificationSteps.push({ ...step, evidence_id: "" });
    }
  }

  const steps = orderSteps([...findings, ...remediationSteps, ...futureVerificationSteps]);
  return { case_id: request.case_id, deletion_status: "INCOMPLETE", steps_json: steps };
}

async function readEvidence(manifest) {
  const evidence = [];
  let ocrWorker;
  try {
    for (const item of manifest) {
      const fullPath = path.join(DATASET, item.file_path);
      const extension = path.extname(fullPath).toLowerCase();
      const capturedAt = item.captured_at;
      if (extension === ".json") {
        const parsed = JSON.parse(await fs.readFile(fullPath, "utf8"));
        walkJson(parsed, {}, item.file_id, capturedAt, evidence);
      } else if (extension === ".sql") {
        const text = await fs.readFile(fullPath, "utf8");
        evidence.push(...parseSqlRecords(text, item.file_id, capturedAt));
      } else if (extension === ".pdf") {
        const parsed = await pdfParse(await fs.readFile(fullPath));
        evidence.push(...parseTextRecords(parsed.text, item.file_id, capturedAt, true));
      } else if (extension === ".png" || extension === ".jpg" || extension === ".jpeg") {
        if (!ocrWorker) {
          ocrWorker = await createWorker("eng", 1, { langPath: englishData.langPath, gzip: englishData.gzip });
        }
        const parsed = await ocrWorker.recognize(fullPath);
        evidence.push(...parseTextRecords(parsed.data.text, item.file_id, capturedAt));
      } else {
        const text = await fs.readFile(fullPath, "utf8");
        evidence.push(...parseTextRecords(text, item.file_id, capturedAt));
      }
    }
  } finally {
    if (ocrWorker) await ocrWorker.terminate();
  }
  return evidence;
}

function collectUsers(identities, auditLog) {
  const byUserId = new Map();
  for (const row of identities) {
    byUserId.set(row.user_id, { userId: row.user_id, values: new Set(Object.values(row).filter(Boolean)) });
  }
  for (const row of auditLog) {
    const user = byUserId.get(row.user_id) ?? { userId: row.user_id, values: new Set() };
    if (row.old_value) user.values.add(row.old_value);
    if (row.new_value) user.values.add(row.new_value);
    byUserId.set(row.user_id, user);
  }
  const emailToUser = new Map();
  for (const user of byUserId.values()) {
    for (const value of user.values) {
      if (String(value).includes("@")) emailToUser.set(normalize(value), user);
    }
  }
  return { byUserId, emailToUser };
}

async function main() {
  const [requests, identities, auditLog, manifest, rules, activity] = await Promise.all([
    readCsv(path.join(DATASET, "deletion_requests.csv")),
    readCsv(path.join(DATASET, "user_identities.csv")),
    readCsv(path.join(DATASET, "user_audit_log.csv")),
    readCsv(path.join(DATASET, "evidence_files.csv")),
    readCsv(path.join(DATASET, "deletion_rules.csv")),
    readCsv(path.join(DATASET, "system_activity.csv")),
  ]);
  if (requests.length !== 518) throw new Error(`Expected 518 requests, found ${requests.length}`);
  if (rules.length === 0 || activity.length === 0) throw new Error("Deletion policy or system activity input is empty");
  const users = collectUsers(identities, auditLog);
  const allEvidence = await readEvidence(manifest);
  const policy = new Map(rules.map((rule) => [rule.data_category, rule.required_action]));
  const rows = requests
    .map((request) => {
      const user = users.emailToUser.get(normalize(request.email));
      if (!user) {
        if (!authorizedDeletion(request.request_text)) {
          return { case_id: request.case_id, deletion_status: "NOT_APPLICABLE", steps_json: [] };
        }
        throw new Error(`Unable to resolve requested email to a current or historical user: ${request.case_id}`);
      }
      return makeOutputCase(request, user, allEvidence, policy, activity);
    })
    .sort((a, b) => a.case_id.localeCompare(b.case_id, undefined, { numeric: true }));

  const output = ["case_id,deletion_status,steps_json"];
  for (const row of rows) {
    output.push([
      writeCsvField(row.case_id),
      writeCsvField(row.deletion_status),
      writeCsvField(JSON.stringify(row.steps_json)),
    ].join(","));
  }
  await fs.writeFile(OUTPUT, `${output.join("\n")}\n`, "utf8");
  const counts = rows.reduce((summary, row) => {
    summary[row.deletion_status] += 1;
    return summary;
  }, { COMPLETE: 0, INCOMPLETE: 0, NOT_APPLICABLE: 0 });
  console.log(`Wrote ${rows.length} cases to ${OUTPUT}`);
  console.log(`Statuses: ${JSON.stringify(counts)}`);
  console.log(`Evidence records indexed: ${allEvidence.length}`);
}

export { authorizedDeletion, collectUsers, makeOutputCase, orderSteps, readCsv, readEvidence };

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.stack : error);
    process.exitCode = 1;
  });
}
